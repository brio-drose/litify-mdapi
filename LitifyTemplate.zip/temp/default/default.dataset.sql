BEGIN TRANSACTION;
CREATE TABLE "Account" (
	id INTEGER NOT NULL, 
	"Description" VARCHAR(255), 
	"Fax" VARCHAR(255), 
	"Name" VARCHAR(255), 
	"AccountNumber" VARCHAR(255), 
	"Phone" VARCHAR(255), 
	"Rating" VARCHAR(255), 
	"Site" VARCHAR(255), 
	"AccountSource" VARCHAR(255), 
	"Type" VARCHAR(255), 
	"AnnualRevenue" VARCHAR(255), 
	"BillingCity" VARCHAR(255), 
	"BillingCountry" VARCHAR(255), 
	"litify_pm__lit_Billing_County__c" VARCHAR(255), 
	"BillingGeocodeAccuracy" VARCHAR(255), 
	"BillingLatitude" VARCHAR(255), 
	"BillingLongitude" VARCHAR(255), 
	"BillingState" VARCHAR(255), 
	"BillingStreet" VARCHAR(255), 
	"BillingPostalCode" VARCHAR(255), 
	"CleanStatus" VARCHAR(255), 
	"DunsNumber" VARCHAR(255), 
	"Jigsaw" VARCHAR(255), 
	"litify_pm__Date_of_birth__c" VARCHAR(255), 
	"litify_pm__Email__c" VARCHAR(255), 
	"NumberOfEmployees" VARCHAR(255), 
	"litify_pm__First_Name__c" VARCHAR(255), 
	"litify_pm__Gender__c" VARCHAR(255), 
	"Industry" VARCHAR(255), 
	"litify_pm__lit_Is_Deceased__c" VARCHAR(255), 
	"litify_pm__Last_Called_At__c" VARCHAR(255), 
	"litify_pm__Last_Emailed_At__c" VARCHAR(255), 
	"litify_pm__Last_Name__c" VARCHAR(255), 
	"NaicsCode" VARCHAR(255), 
	"NaicsDesc" VARCHAR(255), 
	"Ownership" VARCHAR(255), 
	"litify_pm__Phone_Home__c" VARCHAR(255), 
	"litify_pm__Phone_Mobile__c" VARCHAR(255), 
	"litify_pm__Phone_Other__c" VARCHAR(255), 
	"litify_pm__Phone_Work__c" VARCHAR(255), 
	"RecordTypeId" VARCHAR(255), 
	"litify_pm__Salutation__c" VARCHAR(255), 
	"ShippingCity" VARCHAR(255), 
	"ShippingCountry" VARCHAR(255), 
	"litify_pm__lit_Shipping_County__c" VARCHAR(255), 
	"ShippingGeocodeAccuracy" VARCHAR(255), 
	"ShippingLatitude" VARCHAR(255), 
	"ShippingLongitude" VARCHAR(255), 
	"ShippingState" VARCHAR(255), 
	"ShippingStreet" VARCHAR(255), 
	"ShippingPostalCode" VARCHAR(255), 
	"Sic" VARCHAR(255), 
	"SicDesc" VARCHAR(255), 
	"litify_pm__SLA__c" VARCHAR(255), 
	"litify_pm__Social_Security_Number__c" VARCHAR(255), 
	test__c VARCHAR(255), 
	"TickerSymbol" VARCHAR(255), 
	"litify_pm__Total_Calls__c" VARCHAR(255), 
	"litify_pm__Total_Emails__c" VARCHAR(255), 
	"Tradestyle" VARCHAR(255), 
	"litify_pm__Vendor__c" VARCHAR(255), 
	"Website" VARCHAR(255), 
	"YearStarted" VARCHAR(255), 
	"DandbCompanyId" VARCHAR(255), 
	"OperatingHoursId" VARCHAR(255), 
	"ParentId" VARCHAR(255), 
	PRIMARY KEY (id)
);
INSERT INTO "Account" VALUES(1,'','','Account FirstName Account LastName','','','','','','','','','','','','','','','','','Pending','','','','','','Account FirstName','','','False','','','Account LastName','','','','','','','','0127x000008w7xOAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(2,'','','first Last','','','','','','','','','','','','','','','','','Pending','','','','','','first','','','False','','','Last','','','','','','','','0127x000008w7xOAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(3,'','','New York Supreme','','','','','','','','','','','','','','','','','Pending','','','','','','New York','','','False','','','Supreme','','','','','','','','0127x000008w7xOAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(4,'','','MARRIOTT INTERNATIONAL, INC.','','','','','','','','','','','','','','','','','Pending','','','','','','','','','False','','','','','','','','','','','0127x000008w7xNAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(5,'','','Lexitas','','','','','','Technology Partner','','','','','','','','','','','Pending','','','','','','','','','False','','','','','','','','','','','0127x000008w7xNAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(6,'','','MARQUEZ, DAVID STIWARD MEDINA et al','','','','','','','','','','','','','','','','','Pending','','','','','','','','','False','','','','','','','','','','','0127x000008w7xNAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(7,'','','MARTINEZ-REYES, SANDRA','','','','','','','','','','','','','','','','','Pending','','','','','','','','','False','','','','','','','','','','','0127x000008w7xNAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(8,'','','FAIRFIELD TENANT CORP. et al','','','','','','','','','','','','','','','','','Pending','','','','','','','','','False','','','','','','','','','','','0127x000008w7xNAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(9,'','','MOULTRY, TERESA','','','','','','','','','','','','','','','','','Pending','','','','','','','','','False','','','','','','','','','','','0127x000008w7xNAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(10,'','','NEW YORK CITY HOUSING AUTHORITY et al','','','','','','','','','','','','','','','','','Pending','','','','','','','','','False','','','','','','','','','','','0127x000008w7xNAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(11,'','','ALLEYNE, CHRISTOPHER','','','','','','','','','','','','','','','','','Pending','','','','','','','','','False','','','','','','','','','','','0127x000008w7xNAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
INSERT INTO "Account" VALUES(12,'','','SHAIBOOB, AHMED','','','','','','','','','','','','','','','','','Pending','','','','','','','','','False','','','','','','','','','','','0127x000008w7xNAAQ','','','','','','','','','','','','','','','','','0.0','0.0','','False','','','','','');
CREATE TABLE "Account_rt_mapping" (
	record_type_id VARCHAR(18) NOT NULL, 
	developer_name VARCHAR(255), 
	PRIMARY KEY (record_type_id)
);
INSERT INTO "Account_rt_mapping" VALUES('0127x000008w7xNAAQ','Business');
INSERT INTO "Account_rt_mapping" VALUES('0127x000008w7xOAAQ','Individual');
CREATE TABLE "DandBCompany" (
	id INTEGER NOT NULL, 
	"DunsNumber" VARCHAR(255), 
	"Name" VARCHAR(255), 
	PRIMARY KEY (id)
);
CREATE TABLE "Event" (
	id INTEGER NOT NULL, 
	"litify_pm__Default_Matter_Task__c" VARCHAR(255), 
	"litify_pm__Matter_Stage_Activity__c" VARCHAR(255), 
	"litify_pm__Matter__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
INSERT INTO "Event" VALUES(1,'','','');
INSERT INTO "Event" VALUES(2,'','','');
INSERT INTO "Event" VALUES(3,'','','');
CREATE TABLE "OperatingHours" (
	id INTEGER NOT NULL, 
	"Name" VARCHAR(255), 
	"TimeZone" VARCHAR(255), 
	PRIMARY KEY (id)
);
CREATE TABLE "eLaw__c" (
	id INTEGER NOT NULL, 
	"Action__c" VARCHAR(255), 
	"Action_Type__c" VARCHAR(255), 
	"Appearance_Date__c" VARCHAR(255), 
	"Appearance_Id__c" VARCHAR(255), 
	"Appearance_Type__c" VARCHAR(255), 
	"Calendar_Number__c" VARCHAR(255), 
	"Calendar_Remarks__c" VARCHAR(255), 
	"Case_Id__c" VARCHAR(255), 
	"Case_Index__c" VARCHAR(255), 
	"Case_Title__c" VARCHAR(255), 
	"Case_Type_Description__c" VARCHAR(255), 
	"Clerk_Notified__c" VARCHAR(255), 
	"Client__c" VARCHAR(255), 
	"Comments__c" VARCHAR(255), 
	"Complexity__c" VARCHAR(255), 
	"Consolidated_Calendar__c" VARCHAR(255), 
	"Consolidated_Index__c" VARCHAR(255), 
	"Count__c" VARCHAR(255), 
	"County_Clerk_Case_Id__c" VARCHAR(255), 
	"County_Clerk_Id__c" VARCHAR(255), 
	"County_Clerk_Minutes_Id__c" VARCHAR(255), 
	"County_Name__c" VARCHAR(255), 
	"Court_Index_Number__c" VARCHAR(255), 
	"Court_Room__c" VARCHAR(255), 
	"Court_Type__c" VARCHAR(255), 
	"Damage_Type__c" VARCHAR(255), 
	"Docket_Entry_Date__c" VARCHAR(255), 
	"Document_Status__c" VARCHAR(255), 
	"Name" VARCHAR(255), 
	"Judge__c" VARCHAR(255), 
	"Motion_Id__c" VARCHAR(255), 
	"Motion_Relief__c" VARCHAR(255), 
	"Motion_Sequence__c" VARCHAR(255), 
	"Part__c" VARCHAR(255), 
	"RecordTypeId" VARCHAR(255), 
	"Sequence__c" VARCHAR(255), 
	"Series__c" VARCHAR(255), 
	"Matter__c" VARCHAR(255), 
	"eWatch__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
INSERT INTO "eLaw__c" VALUES(1,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','a2K7x0000041tsz','','','','','','','','','','');
INSERT INTO "eLaw__c" VALUES(2,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','a2K7x0000041tt0','','','','','','','','','1','');
INSERT INTO "eLaw__c" VALUES(3,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','a2K7x0000041tt1','','','','','','','','','2','');
INSERT INTO "eLaw__c" VALUES(4,'','TORT-MOTOR VEHICLE','','','','','','0406cfe0-98f6-43e7-86ac-4194605ff611','','','','','','','STANDARD','','','','','','','KINGS','525537.0','','','NON-MONETARY RELIEF','','','a2K7x0000042YJR','','','','','','','','','3','');
INSERT INTO "eLaw__c" VALUES(5,'','','2024-04-18T07:00:00.000+0000','56678569-da8a-446d-867c-fe7ecc7cef83','TO FILE NOI CONFERENCE','','','0406cfe0-98f6-43e7-86ac-4194605ff611','','','','','','','','','','','','','','','','','','','','','a2K7x0000042YJS','Hon. Rachel Freier','','','0.0','NOTE OF ISSUE-FINAL CONFERENCE PART','0127x000008w7e9AAA','17603568.0','','','');
INSERT INTO "eLaw__c" VALUES(6,'HELD','','2023-04-20T07:00:00.000+0000','205be05c-99b1-4a58-9473-12783c45cb76','COMPLIANCE CONFERENCE','','','0406cfe0-98f6-43e7-86ac-4194605ff611','','','','','','','','','','','','','','','','','','','','','a2K7x0000042YJT','Hon. Rachel Freier','','','0.0','CENTRAL COMPLIANCE PART','0127x000008w7e9AAA','16584550.0','','','');
INSERT INTO "eLaw__c" VALUES(7,'HELD','','2022-12-22T08:00:00.000+0000','cd7ba878-4c67-424a-8a85-cfbf905bb9c6','PRELIMINARY CONFERENCE','','','0406cfe0-98f6-43e7-86ac-4194605ff611','','','','','','','','','','','','','','','','','','','','','a2K7x0000042YJU','Hon. Lawrence S. Knipel','','','0.0','INTAKE PART','0127x000008w7e9AAA','16213228.0','','','');
INSERT INTO "eLaw__c" VALUES(8,'','TORT-OTHER NEGLIGENCE','','','','','','38464fc1-ab4b-4360-8dfd-740a30bd50b8','','','','','','','STANDARD','','','','','','','BRONX','808191.0','','','NON-MONETARY RELIEF','','','a2K7x0000042YMf','','','','','','','','','4','');
INSERT INTO "eLaw__c" VALUES(9,'FULLY SUBMITTED','','2023-02-15T08:00:00.000+0000','d84d3f7f-1c3d-4916-957f-d3db98edec71','INITIAL SUBMISSION MOTION','','','38464fc1-ab4b-4360-8dfd-740a30bd50b8','','','','','','','','','','','','','','','','','','','','','a2K7x0000042YMg','Hon. Mary Ann Brigantti','649adf15-f820-4020-9f94-41e89b1b27c4','JUDGMENT - DEFAULT','1.0','Submission Motions-Room 217','0127x000008w7e9AAA','16589479.0','','','');
INSERT INTO "eLaw__c" VALUES(10,'','OM-OTHER','','','','','','0ebaf2ee-c411-4b80-9753-e6aeec4faac2','','','','','','','STANDARD','','','','','','','KINGS','505489.0','','','NON-MONETARY RELIEF','','','a2K7x0000042ZLx','','','','','','','','','7','');
INSERT INTO "eLaw__c" VALUES(11,'FULLY SUBMITTED','','2022-03-16T07:00:00.000+0000','09ee1ebf-ca88-4a8f-ba4b-b6f3abd706d8','NOTICE OF MOTION MOTION','','','0ebaf2ee-c411-4b80-9753-e6aeec4faac2','','','','','','','','','','','','','','','','','','','','','a2K7x0000042ZLy','Hon. Lillian Wan','250ed26d-5859-43aa-880a-609ed2211f5b','JUDGMENT - DEFAULT','4.0','MOTION PART 17','0127x000008w7e9AAA','14366072.0','','','');
INSERT INTO "eLaw__c" VALUES(12,'DENIED','','2020-12-22T08:00:00.000+0000','38ddffa5-6112-4eb2-b233-9a9311c79469','CROSS-MOTION MOTION','','','0ebaf2ee-c411-4b80-9753-e6aeec4faac2','','','','','','','','','','','','','','','','','','','','','a2K7x0000042ZLz','Hon. Rosemarie Montalbano','7012f299-dcfe-4c97-bd60-a6212ee1e283','AMEND CAPTION/PLEADINGS','3.0','Motion Part 7','0127x000008w7e9AAA','5654514.0','','','');
INSERT INTO "eLaw__c" VALUES(13,'GRANTED','','2020-12-10T08:00:00.000+0000','ff9bc04c-01f8-481f-b548-9b988e321847','OTHER MOTION','','2PM (Conversion)','0ebaf2ee-c411-4b80-9753-e6aeec4faac2','','','','','','','','','','','','','','','','','','','','','a2K7x0000042ZM0','Hon. Rosemarie Montalbano','32bbdad8-5a86-4f10-a898-e1ad15b61004','DISMISS','2.0','Motion Trial Term 7','0127x000008w7e9AAA','4973679.0','','','');
INSERT INTO "eLaw__c" VALUES(14,'ADJOURNED','','2020-10-23T07:00:00.000+0000','0d94b63f-8d24-47fa-af03-eacdbc6bd07b','OTHER MOTION','','2PM (Conversion)','0ebaf2ee-c411-4b80-9753-e6aeec4faac2','','','','','','','','','','','','','','','','','','','','','a2K7x0000042ZM1','Hon. Rosemarie Montalbano','32bbdad8-5a86-4f10-a898-e1ad15b61004','DISMISS','2.0','SUBSEQUENT MOTION PART','0127x000008w7e9AAA','4973678.0','','','');
INSERT INTO "eLaw__c" VALUES(15,'DECIDED','','2020-09-08T07:00:00.000+0000','e90b775d-7a6d-43ed-8e63-9e5a0a89140c','OTHER MOTION','','PER STIP (Conversion)','0ebaf2ee-c411-4b80-9753-e6aeec4faac2','','','','','','','','','','','','','','','','','','','','','a2K7x0000042ZM2','Hon. Rosemarie Montalbano','28174f80-01a5-4129-9635-7f966e8087ea','DISMISS','1.0','Motion Trial Term 7','0127x000008w7e9AAA','4973677.0','','','');
INSERT INTO "eLaw__c" VALUES(16,'ADJOURNED','','2020-07-24T07:00:00.000+0000','4558aa82-6b29-41f3-8671-40174aaadcb2','OTHER MOTION','','','0ebaf2ee-c411-4b80-9753-e6aeec4faac2','','','','','','','','','','','','','','','','','','','','','a2K7x0000042ZM3','Hon. Johnny Lee Baynes','28174f80-01a5-4129-9635-7f966e8087ea','DISMISS','1.0','MOTION PART','0127x000008w7e9AAA','4973676.0','','','');
INSERT INTO "eLaw__c" VALUES(17,'','TORT-OTHER','','','','2018L-03365','','1c87979f-25ab-4996-b512-2840309c5108','','','','','','','STANDARD','','','','','','','NEW YORK','154317.0','','','NON-MONETARY RELIEF','','','a2K7x0000047Px3','','','','','','0127x000008w7e9AAA','','','8','');
INSERT INTO "eLaw__c" VALUES(18,'','TORT-MOTOR VEHICLE','','','','','','f5c4ecd2-ece4-4622-8aac-8c9741908166','','','','','','','STANDARD','','','','','','','BRONX','801910.0','','','NON-MONETARY RELIEF','','','a2K7x0000047Pyf','','','','','','0127x000008w7e9AAA','','','8','');
INSERT INTO "eLaw__c" VALUES(19,'HELD','','2021-11-09T08:00:00.000+0000','98a2ff20-943f-48d0-94b6-25d9347b0099','PRELIMINARY CONFERENCE','','CSO SIGNED','f5c4ecd2-ece4-4622-8aac-8c9741908166','','','','','','CSO SIGNED','','','','','','','','','','','','','','','a2K7x0000047Pyg','Hon. Ben R. Barbato','','','0.0','','0127x000008w7e9AAA','14070879.0','','','');
INSERT INTO "eLaw__c" VALUES(20,'FULLY SUBMITTED','','2023-08-10T07:00:00.000+0000','8b9df4c6-2e70-4909-b958-3a5ab1fd7558','INITIAL SUBMISSION MOTION','','','f5c4ecd2-ece4-4622-8aac-8c9741908166','','','','','','','','','','','','','','','','','','','','','a2K7x0000047Pyh','Hon. Ben R. Barbato','fc174440-a2c3-4a8d-b407-5b6a02985076','JOIN FOR TRIAL','2.0','Submission Motions-Room 217','0127x000008w7e9AAA','17910031.0','','','');
INSERT INTO "eLaw__c" VALUES(21,'FULLY SUBMITTED','','2022-04-18T07:00:00.000+0000','f2fca49a-8492-4e93-878d-b4cce069b735','INITIAL SUBMISSION MOTION','','','f5c4ecd2-ece4-4622-8aac-8c9741908166','','','','','','','','','','','','','','','','','','','','','a2K7x0000047Pyi','Hon. Ben R. Barbato','53282e8a-98e8-4558-9003-564768650703','COMPEL','1.0','Submission Motions-Room 217','0127x000008w7e9AAA','15013121.0','','','');
INSERT INTO "eLaw__c" VALUES(22,'','TORT-OTHER NEGLIGENCE','','','','','','594c5691-66d8-447e-be3c-e4fdde2008f0','','','','','','','STANDARD','','','','','','','BRONX','816993.0','','','NON-MONETARY RELIEF','','','a2K7x0000047QTJ','','','','','','0127x000008w7e9AAA','','','11','');
INSERT INTO "eLaw__c" VALUES(23,'CLOSED','','2023-06-06T07:00:00.000+0000','6bd65706-934c-43a2-8988-a0a3a3ab772e','PRELIMINARY CONFERENCE','','See part rules/Part 11','594c5691-66d8-447e-be3c-e4fdde2008f0','','','','','','','','','','','','','','','','','','','','','a2K7x0000047QTK','Hon. Mitchell J. Danziger','','','0.0','City - IA3','0127x000008w7e9AAA','17611819.0','','','');
INSERT INTO "eLaw__c" VALUES(24,'FULLY SUBMITTED','','2023-06-21T07:00:00.000+0000','573954ae-8991-4950-b081-7a65b1ab3792','INITIAL SUBMISSION MOTION','','','594c5691-66d8-447e-be3c-e4fdde2008f0','','','','','','','','','','','','','','','','','','','','','a2K7x0000047QTL','Hon. Marissa Soto','47034889-4850-4491-aafc-8506b19da359','DISMISS','2.0','Submission Motions-Room 217','0127x000008w7e9AAA','17712296.0','','','');
INSERT INTO "eLaw__c" VALUES(25,'FULLY SUBMITTED','','2023-06-21T07:00:00.000+0000','3480a161-2f41-41f6-a1ff-54e0349aa46d','RESUBMISSION MOTION','','','594c5691-66d8-447e-be3c-e4fdde2008f0','','','','','','','','','','','','','','','','','','','','','a2K7x0000047QTM','Hon. Marissa Soto','d56486e7-3e14-4f35-b395-caafe44466f1','JUDGMENT - DEFAULT','1.0','Submission Motions-Room 217','0127x000008w7e9AAA','17813569.0','','','');
INSERT INTO "eLaw__c" VALUES(26,'ADJOURNED','','2023-06-08T07:00:00.000+0000','e418f034-16a1-4fcd-b8c3-272f09c7f791','INITIAL SUBMISSION MOTION','','','594c5691-66d8-447e-be3c-e4fdde2008f0','','','','','','','','','','','','','','','','','','','','','a2K7x0000047QTN','Hon. Mitchell J. Danziger','d56486e7-3e14-4f35-b395-caafe44466f1','JUDGMENT - DEFAULT','1.0','Submission Motions-Room 217','0127x000008w7e9AAA','17691418.0','','','');
INSERT INTO "eLaw__c" VALUES(27,'','TORT-MOTOR VEHICLE','','','','','','9357d370-0ff2-480c-9802-6be53d5c6994','','','','','','','STANDARD','','','','','','','BRONX','23268.0','','','NON-MONETARY RELIEF','','','a2K7x0000047QY9','','','','','','0127x000008w7e9AAA','','','11','');
INSERT INTO "eLaw__c" VALUES(28,'CLOSED','','2021-10-04T07:00:00.000+0000','7925cbda-1057-4d54-9bb3-4f84903dcd01','OTHER CONVERSION','','PER SFO (Conversion)','9357d370-0ff2-480c-9802-6be53d5c6994','','','','','','Conference appearance closed per Adminis','','','','','','','','','','','','','','','a2K7x0000047QYA','Hon. Ben R. Barbato','','','0.0','Mv 15 Pre Conf','0127x000008w7e9AAA','12710339.0','','','');
INSERT INTO "eLaw__c" VALUES(29,'ADJOURNED','','2021-08-03T07:00:00.000+0000','6532eba1-b5b2-4d4d-8c40-a26d0111a69e','OTHER CONVERSION','','PER SFO (Conversion)','9357d370-0ff2-480c-9802-6be53d5c6994','','','','','','','','','','','','','','','','','','','','','a2K7x0000047QYB','Hon. Ben R. Barbato','','','0.0','Mv 15 Pre Conf','0127x000008w7e9AAA','12710338.0','','','');
INSERT INTO "eLaw__c" VALUES(30,'ADJOURNED','','2021-05-18T07:00:00.000+0000','7c4f848f-d39d-4c46-ad92-8ea7e3eee468','OTHER CONVERSION','','PER SFO 3/16/2021 (Conversion)','9357d370-0ff2-480c-9802-6be53d5c6994','','','','','','','','','','','','','','','','','','','','','a2K7x0000047QYC','Hon. Mary Ann Brigantti','','','0.0','Mv 15 Pre Conf','0127x000008w7e9AAA','12710337.0','','','');
INSERT INTO "eLaw__c" VALUES(31,'FULLY SUBMITTED','','2020-08-21T07:00:00.000+0000','f4624a22-1147-4b19-93dd-e40150a380f4','OTHER MOTION','','15P (Conversion)','9357d370-0ff2-480c-9802-6be53d5c6994','','','','','','','','','','','','','','','','','','','','','a2K7x0000047QYD','Hon. Mary Ann Brigantti','e569120a-46df-4e38-abd2-697d33636314','PRECLUDE','1.0','Submission Motions-Room 217','0127x000008w7e9AAA','12710340.0','','','');
INSERT INTO "eLaw__c" VALUES(32,'','','','','','','','d3dd46c1-d69e-4be8-8059-25019bd88420','','','','','','','','','','','','','','KINGS','505513.0','','','','','','a2K7x0000047cKn','','','','','','0127x000008w7e9AAA','','','12','');
CREATE TABLE "eLaw__c_rt_mapping" (
	record_type_id VARCHAR(18) NOT NULL, 
	developer_name VARCHAR(255), 
	PRIMARY KEY (record_type_id)
);
INSERT INTO "eLaw__c_rt_mapping" VALUES('0127x000008w7e9AAA','Appearance');
CREATE TABLE "eWatch__c" (
	id INTEGER NOT NULL, 
	"API_Response__c" VARCHAR(255), 
	"Ended_Date__c" VARCHAR(255), 
	"Request__c" VARCHAR(255), 
	"Result__c" VARCHAR(255), 
	"Matter__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
INSERT INTO "eWatch__c" VALUES(1,'','','','','1');
INSERT INTO "eWatch__c" VALUES(2,'','','','','2');
INSERT INTO "eWatch__c" VALUES(3,'','','Start_eWatch','Succeeded','1');
INSERT INTO "eWatch__c" VALUES(4,'','','Start_eWatch','Succeeded','1');
INSERT INTO "eWatch__c" VALUES(5,'','','Start_eWatch','Succeeded','1');
INSERT INTO "eWatch__c" VALUES(6,'','','Start_eWatch','Succeeded','3');
INSERT INTO "eWatch__c" VALUES(7,'','','Start_eWatch','Succeeded','4');
INSERT INTO "eWatch__c" VALUES(8,'','','Start_eWatch','Succeeded','4');
INSERT INTO "eWatch__c" VALUES(9,'','','Start_eWatch','Succeeded','4');
INSERT INTO "eWatch__c" VALUES(10,'','','Start_eWatch','Succeeded','5');
INSERT INTO "eWatch__c" VALUES(11,'','','Start_eWatch','Succeeded','6');
INSERT INTO "eWatch__c" VALUES(12,'','','Start_eWatch','Succeeded','7');
INSERT INTO "eWatch__c" VALUES(13,'','','Start_eWatch','Succeeded','8');
INSERT INTO "eWatch__c" VALUES(14,'','','Start_eWatch','Succeeded','8');
INSERT INTO "eWatch__c" VALUES(15,'','','Start_eWatch','Succeeded','9');
INSERT INTO "eWatch__c" VALUES(16,'','','Start_eWatch','Succeeded','9');
INSERT INTO "eWatch__c" VALUES(17,'','','Start_eWatch','Succeeded','11');
INSERT INTO "eWatch__c" VALUES(18,'','','Start_eWatch','Succeeded','11');
INSERT INTO "eWatch__c" VALUES(19,'','','Start_eWatch','Succeeded','11');
INSERT INTO "eWatch__c" VALUES(20,'','','Start_eWatch','Succeeded','12');
CREATE TABLE "litify_ext__Merge_Assistant__c" (
	id INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE "litify_pm__Case_Type__c" (
	id INTEGER NOT NULL, 
	"Name" VARCHAR(255), 
	"litify_ext__Intake_Record_Type_Name__c" VARCHAR(255), 
	"litify_ext__Matter_Record_Type_Name__c" VARCHAR(255), 
	"litify_pm__ExternalId__c" VARCHAR(255), 
	"litify_pm__Is_Available__c" VARCHAR(255), 
	"litify_pm__Litigation_Type__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
INSERT INTO "litify_pm__Case_Type__c" VALUES(1,'New York Supreme','','','','False','');
INSERT INTO "litify_pm__Case_Type__c" VALUES(2,'Civil','','','','False','');
CREATE TABLE "litify_pm__Companion__c" (
	id INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE "litify_pm__Default_Matter_Task__c" (
	id INTEGER NOT NULL, 
	"litify_pm__Matter_Stage__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
CREATE TABLE "litify_pm__Default_Matter_Team__c" (
	id INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE "litify_pm__Firm__c" (
	id INTEGER NOT NULL, 
	"litify_pm__ExternalId__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
CREATE TABLE "litify_pm__Intake__c" (
	id INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE "litify_pm__Matter_Plan__c" (
	id INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE "litify_pm__Matter_Stage_Activity__c" (
	id INTEGER NOT NULL, 
	"litify_pm__Order__c" VARCHAR(255), 
	"litify_pm__Stage_Status__c" VARCHAR(255), 
	"litify_pm__Matter__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
CREATE TABLE "litify_pm__Matter_Stage__c" (
	id INTEGER NOT NULL, 
	"litify_pm__Stage_Order__c" VARCHAR(255), 
	"litify_pm__Matter_Plan__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
CREATE TABLE "litify_pm__Matter__c" (
	id INTEGER NOT NULL, 
	"casewatchID__c" VARCHAR(255), 
	"eLaw_case_id__c" VARCHAR(255), 
	"eWatch_Status__c" VARCHAR(255), 
	"litify_ext__MTM_Ids2__c" VARCHAR(255), 
	"litify_ext__MTM_Ids__c" VARCHAR(255), 
	"litify_ext__Private__c" VARCHAR(255), 
	"litify_pm__Abbreviated_Users_1__c" VARCHAR(255), 
	"litify_pm__Abbreviated_Users_2__c" VARCHAR(255), 
	"litify_pm__Abbreviated_Users_3__c" VARCHAR(255), 
	"litify_pm__Amount_Due_to_Client__c" VARCHAR(255), 
	"litify_pm__Billable_Matter__c" VARCHAR(255), 
	"litify_pm__Billing_Type__c" VARCHAR(255), 
	"litify_pm__Budget__c" VARCHAR(255), 
	"litify_pm__Case_Title__c" VARCHAR(255), 
	"litify_pm__Client_Portal_Status__c" VARCHAR(255), 
	"litify_pm__Close_Date__c" VARCHAR(255), 
	"litify_pm__Closed_Date__c" VARCHAR(255), 
	"litify_pm__Closed_Reason_Details__c" VARCHAR(255), 
	"litify_pm__Closed_Reason__c" VARCHAR(255), 
	"litify_pm__Contingency_Fee_Rate__c" VARCHAR(255), 
	"litify_pm__Description__c" VARCHAR(255), 
	"litify_pm__Discharge_Date__c" VARCHAR(255), 
	"litify_pm__Display_Name__c" VARCHAR(255), 
	"litify_pm__Docket_Number__c" VARCHAR(255), 
	"litify_pm__Fee_Amount__c" VARCHAR(255), 
	"litify_pm__FeesDueToOthers__c" VARCHAR(255), 
	"litify_pm__Filed_Date__c" VARCHAR(255), 
	"litify_pm__Gross_Recovery__c" VARCHAR(255), 
	"litify_pm__Hard_Costs__c" VARCHAR(255), 
	"litify_pm__Hourly_Rate__c" VARCHAR(255), 
	"litify_pm__Ignore_Default_Plan__c" VARCHAR(255), 
	"litify_pm__Incident_date__c" VARCHAR(255), 
	"litify_pm__Last_Called_At__c" VARCHAR(255), 
	"litify_pm__Last_Emailed_At__c" VARCHAR(255), 
	"litify_pm__Limitations_date_satisfied__c" VARCHAR(255), 
	"litify_pm__Lost_Reason__c" VARCHAR(255), 
	"litify_pm__Manual_Statute_of_Limitations__c" VARCHAR(255), 
	"litify_pm__Matter_Address_1__c" VARCHAR(255), 
	"litify_pm__Matter_Address_2__c" VARCHAR(255), 
	"litify_pm__Matter_City__c" VARCHAR(255), 
	"litify_pm__Matter_Has_Budget__c" VARCHAR(255), 
	"litify_pm__Matter_Postal_Code__c" VARCHAR(255), 
	"litify_pm__Matter_State__c" VARCHAR(255), 
	"litify_pm__Matter_Team_Modified__c" VARCHAR(255), 
	"litify_pm__Moved_to_Litigation__c" VARCHAR(255), 
	"litify_pm__Net_Attorney_Fee__c" VARCHAR(255), 
	"litify_pm__Net_Recovery__c" VARCHAR(255), 
	"litify_pm__Notify_users_when_budget_reached__c" VARCHAR(255), 
	"litify_pm__Open_Date__c" VARCHAR(255), 
	"litify_pm__Pending_Date__c" VARCHAR(255), 
	"litify_pm__Pre_Lit_Offer_Amount__c" VARCHAR(255), 
	"litify_pm__Soft_Costs__c" VARCHAR(255), 
	"litify_pm__Source_Type__c" VARCHAR(255), 
	"litify_pm__Status__c" VARCHAR(255), 
	"litify_pm__Statute_Of_Limitations__c" VARCHAR(255), 
	"litify_pm__Total_Calls__c" VARCHAR(255), 
	"litify_pm__Total_Emails__c" VARCHAR(255), 
	"litify_pm__Total_Matter_Value__c" VARCHAR(255), 
	"litify_pm__Trial_Date__c" VARCHAR(255), 
	"litify_pm__Turn_Down_Details__c" VARCHAR(255), 
	"litify_pm__Use_same_client_location__c" VARCHAR(255), 
	"litify_pm__lit_Exact_Source__c" VARCHAR(255), 
	"litify_pm__lit_Matter_County__c" VARCHAR(255), 
	"litify_pm__lit_Partner_Attorney_Fee__c" VARCHAR(255), 
	"litify_pm__lit_Referral_Partner_Fee_Percent__c" VARCHAR(255), 
	"RecordTypeId" VARCHAR(255), 
	"Internal_Law_Firm__c" VARCHAR(255), 
	"Latest_eLaw__c" VARCHAR(255), 
	"litify_ext__Merge_Assistant__c" VARCHAR(255), 
	"litify_pm__Case_Type__c" VARCHAR(255), 
	"litify_pm__Client__c" VARCHAR(255), 
	"litify_pm__Companion__c" VARCHAR(255), 
	"litify_pm__Court__c" VARCHAR(255), 
	"litify_pm__Default_Matter_Team__c" VARCHAR(255), 
	"litify_pm__Matter_Plan__c" VARCHAR(255), 
	"litify_pm__Matter_Stage_Activity__c" VARCHAR(255), 
	"litify_pm__OpposingParty__c" VARCHAR(255), 
	"litify_pm__Primary_Intake__c" VARCHAR(255), 
	"litify_pm__Referral__c" VARCHAR(255), 
	"litify_pm__Source__c" VARCHAR(255), 
	"litify_pm__Starting_Matter_Stage_Override__c" VARCHAR(255), 
	"litify_pm__lit_Referral_Partner__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
INSERT INTO "litify_pm__Matter__c" VALUES(1,'0e78b93e-bbbe-4fa8-87a0-7ef053535534','47f01c57-4cd4-4b2c-8abb-ec5187ed6760','Active','','','False','','','','','True','','','','Open','','','','','','','','Account FirstName Account LastName','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-10-11','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','','1','','','','','','','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(2,'2bb67bdc-7fc3-4d5c-9e37-a47818cdffea','21ac8859-eb74-4654-a1fb-29308e6ec35d','Active','','','False','','','','','True','','','','Open','','','','','','','','first Last','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-10-16','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','','2','','','','','','','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(3,'2c856f25-9b81-4901-a8c4-43af02de6c89','0406cfe0-98f6-43e7-86ac-4194605ff611','Active','','','False','','','','','True','','','','Open','','','','','','','','Sample Account for Entitlements','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-11-10','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','','0017x00000Kb5GZAAZ','','','','','','','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(4,'d205dcb6-2b9a-40cf-809c-06beee4e70dc','38464fc1-ab4b-4360-8dfd-740a30bd50b8','Active','','','False','','','','','True','','','','Open','','','','','','','','Sample Account for Entitlements','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-11-10','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','','0017x00000Kb5GZAAZ','','','','','','','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(5,'','','Active','','','False','','','','','True','','','','Open','','','','','','','','Sample Account for Entitlements','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-11-10','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','','0017x00000Kb5GZAAZ','','','','','','','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(6,'','','Active','','','False','','','','','True','','','','Open','','','','','','','','first Last','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-11-10','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','','2','','','','','','','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(7,'3f668e3c-6333-46af-ac6e-296982078764','0ebaf2ee-c411-4b80-9753-e6aeec4faac2','Active','','','False','','','','','True','','','','Open','','','','','','','','BIG MATTER ALERT','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-11-10','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','','2','','','','','','','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(8,'6468bde9-7123-49bd-995d-2a4f32a04752','f5c4ecd2-ece4-4622-8aac-8c9741908166','Active','','','False','','','','','True','','','','Open','','','','','','','','ZEIGER, MARTIN v. MARRIOTT INTERNATIONAL, INC.','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-11-27','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','2','5','','3','','','','4','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(9,'','','Active','','','False','','','','','True','','','','Open','','','','','','','','FAMILIA, ISAIAH et al v.MARQUEZ, DAVID STIWARD MEDINA et al','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-11-27','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','2','5','','3','','','','6','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(10,'6DB293EC-B664-4BCF-96D9-37AB61C0A691','12069143','Active','','','False','','','','','True','','','','Open','','','','','','','','MARTINEZ-REYES, SANDRA v.FAIRFIELD TENANT CORP. et al','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-11-27','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','1','7','','3','','','','8','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(11,'afbd9b25-9de1-4bf3-b1b1-6c19fedd29b3','9357d370-0ff2-480c-9802-6be53d5c6994','Active','','','False','','','','','True','','','','Open','','','','','','','','MOULTRY, TERESA v.NEW YORK CITY HOUSING AUTHORITY et al','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-11-27','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','2','9','','3','','','','10','','','','','');
INSERT INTO "litify_pm__Matter__c" VALUES(12,'157e3ba5-9bbf-43ef-a4ff-8a10e918a706','d3dd46c1-d69e-4be8-8059-25019bd88420','Active','','','False','','','','','True','','','','Open','','','','','','','','ALLEYNE, CHRISTOPHER v.SHAIBOOB, AHMED OBAYAH et al','','','','','','','','False','','','','False','','False','','','','False','','','False','','','','','2023-11-28','','','','','Open','','0.0','0.0','0.0','','','True','','','','','0127x000008w7xVAAQ','','','','','11','','','','','','12','','','','','');
CREATE TABLE "litify_pm__Matter__c_rt_mapping" (
	record_type_id VARCHAR(18) NOT NULL, 
	developer_name VARCHAR(255), 
	PRIMARY KEY (record_type_id)
);
INSERT INTO "litify_pm__Matter__c_rt_mapping" VALUES('0127x000008w7xVAAQ','Billable_Matter');
INSERT INTO "litify_pm__Matter__c_rt_mapping" VALUES('0127x000008w7xWAAQ','Non_Billable_Matter');
CREATE TABLE "litify_pm__Referral__c" (
	id INTEGER NOT NULL, 
	"litify_pm__Client_First_Name__c" VARCHAR(255), 
	"litify_pm__Client_Last_Name__c" VARCHAR(255), 
	"litify_pm__Case_Type__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
CREATE TABLE "litify_pm__Source__c" (
	id INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
COMMIT;
