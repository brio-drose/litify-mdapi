BEGIN TRANSACTION;
CREATE TABLE "litify_pm__lit_AT_Child__c" (
	id INTEGER NOT NULL, 
	"litify_pm__lit_AT_Timeline_View__c" VARCHAR(255), 
	PRIMARY KEY (id)
);
INSERT INTO "litify_pm__lit_AT_Child__c" VALUES(1,'1');
INSERT INTO "litify_pm__lit_AT_Child__c" VALUES(2,'1');
CREATE TABLE "litify_pm__lit_AT_Timeline_View__c" (
	id INTEGER NOT NULL, 
	"Name" VARCHAR(255), 
	PRIMARY KEY (id)
);
INSERT INTO "litify_pm__lit_AT_Timeline_View__c" VALUES(1,'litify_pm__Matter__c');
COMMIT;
